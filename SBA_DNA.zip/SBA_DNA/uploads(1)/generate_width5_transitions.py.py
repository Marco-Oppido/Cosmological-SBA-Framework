#!/usr/bin/env python3
"""
generate_width5_transitions.py

Exhaustive width-5 transition table generator and verification tool for the
Specular Bit Architecture (SBA) compute-phase, boundary rules, and sanitization-phase simulation.

Outputs (written to ./outputs):
 - width5_transitions_full.csv
 - appendixB_part1.tex ... appendixB_part5.tex
 - verification_report.txt
 - sanitization_examples.txt
 - README_GENERATION.txt

Requirements: Python 3.8+. Uses only Python standard library.

Author: Marco Oppido
Date: 03-21-2026
"""

from __future__ import annotations
import csv
import itertools
import math
import os
from typing import Dict, List, Tuple

# ---------------------------
# Configuration
# ---------------------------

OUTPUT_DIR = "outputs"
CSV_FILENAME = os.path.join(OUTPUT_DIR, "width5_transitions_full.csv")
TEX_PART_PREFIX = os.path.join(OUTPUT_DIR, "appendixB_part")
VERIFICATION_FILENAME = os.path.join(OUTPUT_DIR, "verification_report.txt")
SANITIZATION_EXAMPLES = os.path.join(OUTPUT_DIR, "sanitization_examples.txt")
README_FILE = os.path.join(OUTPUT_DIR, "README_GENERATION.txt")

DIGITS = [-2, -1, 0, 1, 2]
ROWS_PER_PART = 625  # 3125 / 5

# Fibonacci offset (W_k = F_{k + OFFSET_O})
OFFSET_O = 0

# Protocol C parameters (used in sanitization arbitration)
ALPHA = 1.0
BETA = 1.0
GAMMA = 2.0

# Reconstruction radius for candidate proposals
RECON_RADIUS = 2

# ---------------------------
# Utility functions
# ---------------------------

def ensure_output_dir():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

def fib(n: int, memo: Dict[int, int] = None) -> int:
    """
    Compute Fibonacci number F_n for integer n (supports negative indices).
    Uses F_0 = 0, F_1 = 1 and F_{-n} = (-1)^{n+1} F_n.
    """
    if memo is None:
        memo = {0: 0, 1: 1}
    if n in memo:
        return memo[n]
    if n > 1:
        for k in range(2, n + 1):
            if k not in memo:
                memo[k] = memo[k - 1] + memo[k - 2]
        return memo[n]
    # negative index
    pos = -n
    pos_val = fib(pos, memo)
    sign = -1 if (pos % 2 == 0) else 1
    return sign * pos_val

def compute_weights(indices: List[int], offset: int = 0) -> Dict[int, int]:
    """Compute positional weights W_k = F_{k + offset} for given indices."""
    return {k: fib(k + offset) for k in indices}

def weighted_sum(neigh: Tuple[int, int, int, int, int], weights: Dict[int, int]) -> int:
    """Compute weighted sum sum_{k=-2..2} d_k * W_k."""
    keys = [-2, -1, 0, 1, 2]
    return sum(neigh[i] * weights[keys[i]] for i in range(5))

def info_mass(neigh: Tuple[int, int, int, int, int], weights: Dict[int, int], m0: float = 1.0) -> float:
    """Informational mass M(V) = m0 * sum |v_i| W_i over the 5-tuple."""
    keys = [-2, -1, 0, 1, 2]
    return m0 * sum(abs(neigh[i]) * weights[keys[i]] for i in range(5))

def latex_escape(s: str) -> str:
    """Minimal LaTeX escaping for underscores and percent signs in table cells."""
    return s.replace("_", "\\_").replace("%", "\\%").replace("&", "\\&")

# ---------------------------
# SBA rewrite rules
# ---------------------------

def interior_rewrite(neigh: Tuple[int, int, int, int, int]) -> Tuple[str, Tuple[int, int, int, int, int]]:
    """
    Interior rewrite centered at d0:
      if d0 == +2:
        d0 <- d0 - 2
        d1 <- d1 + 1
        d-2 <- d-2 + 1
      if d0 == -2:
        d0 <- d0 + 2
        d1 <- d1 - 1
        d-2 <- d-2 - 1
      else: none
    """
    d_m2, d_m1, d0, d1, d2 = neigh
    if d0 == 2:
        return ("rewrite_plus2", (d_m2 + 1, d_m1, d0 - 2, d1 + 1, d2))
    if d0 == -2:
        return ("rewrite_minus2", (d_m2 - 1, d_m1, d0 + 2, d1 - 1, d2))
    return ("none", neigh)

def boundary_rule_i0(neigh: Tuple[int, int, int, int, int]) -> Tuple[str, Tuple[int, int, int, int, int]]:
    """
    Boundary rule for i = 0 (leftmost index):
      if d0 == +2:
        d0 <- d0 - 2
        d1 <- d1 + 1
      if d0 == -2:
        d0 <- d0 + 2
        d1 <- d1 - 1
    """
    d_m2, d_m1, d0, d1, d2 = neigh
    if d0 == 2:
        return ("boundary_i0_plus2", (d_m2, d_m1, d0 - 2, d1 + 1, d2))
    if d0 == -2:
        return ("boundary_i0_minus2", (d_m2, d_m1, d0 + 2, d1 - 1, d2))
    return ("none", neigh)

def boundary_rule_i1(neigh: Tuple[int, int, int, int, int]) -> Tuple[str, Tuple[int, int, int, int, int]]:
    """
    Boundary rule for i = 1:
      if d1 == +2:
        d1 <- d1 - 2
        d2 <- d2 + 1
        d0 <- d0 + 1
      if d1 == -2:
        d1 <- d1 + 2
        d2 <- d2 - 1
        d0 <- d0 - 1
    """
    d_m2, d_m1, d0, d1, d2 = neigh
    if d1 == 2:
        return ("boundary_i1_plus2", (d_m2, d_m1, d0 + 1, d1 - 2, d2 + 1))
    if d1 == -2:
        return ("boundary_i1_minus2", (d_m2, d_m1, d0 - 1, d1 + 2, d2 - 1))
    return ("none", neigh)

# ---------------------------
# Sanitization-phase reconstructor and Protocol C simulation
# ---------------------------

def deterministic_reconstructor(post_neigh: Tuple[int, int, int, int, int]) -> Dict[int, List[Tuple[int, int]]]:
    """
    For each source index i in neighborhood, propose candidate injections to targets j within radius RECON_RADIUS.
    Deterministic rule used here:
      - compute local signal s = d_{i-1} + d_{i+1}
      - proposed candidate value v = sign(s) in {-1,0,1}
      - propose to all targets j with |i-j| <= RECON_RADIUS (bounded to -2..2)
    Returns mapping target_j -> list of (source_i, candidate_value)
    """
    mapping = {j: [] for j in range(-2, 3)}
    d = {k: post_neigh[idx] for idx, k in enumerate(range(-2, 3))}
    for i in range(-2, 3):
        left = d.get(i - 1, 0)
        right = d.get(i + 1, 0)
        s = left + right
        if s > 0:
            v = 1
        elif s < 0:
            v = -1
        else:
            v = 0
        for j in range(max(-2, i - RECON_RADIUS), min(2, i + RECON_RADIUS) + 1):
            mapping[j].append((i, v))
    return mapping

def protocol_c_arbitrate(mapping: Dict[int, List[Tuple[int, int]]],
                        post_neigh: Tuple[int, int, int, int, int],
                        weights: Dict[int, int],
                        m0: float = 1.0) -> Tuple[Tuple[int, int, int, int, int], List[str]]:
    """
    Simulate Protocol C arbitration per target:
      - For each candidate (i->j) compute energy score:
          E = ALPHA * DeltaM_local + BETA * |i-j| + GAMMA * penalty_zero_value
      - DeltaM_local computed over full 5-tuple (local model)
      - Deterministic tie-break: smaller source index i wins
      - Commit at most one injection per target
    Returns (post_sanitized_neigh, trace_lines)
    """
    d = {k: post_neigh[idx] for idx, k in enumerate(range(-2, 3))}
    trace = []
    committed = {j: 0 for j in range(-2, 3)}
    for j in range(-2, 3):
        candidates = mapping.get(j, [])
        if not candidates:
            continue
        best = None
        best_key = None
        for (i, v) in candidates:
            before = info_mass(tuple(d[k] for k in range(-2, 3)), weights, m0)
            d_after = d.copy()
            d_after[j] = d_after[j] + v
            after = info_mass(tuple(d_after[k] for k in range(-2, 3)), weights, m0)
            deltaM_local = after - before
            penalty = 1.0 if v == 0 else 0.0
            E = ALPHA * deltaM_local + BETA * abs(i - j) + GAMMA * penalty
            key = (E, i)
            if best is None or key < best_key:
                best = (i, v)
                best_key = key
        if best is not None:
            committed[j] = best[1]
            trace.append(f"target {j}: winner source {best[0]} value {best[1]} score {best_key[0]:.6f}")
    final = tuple(d[k] + committed[k] for k in range(-2, 3))
    return final, trace

# ---------------------------
# Generation and outputs
# ---------------------------

def generate_rows() -> Tuple[List[Dict[str, object]], Dict[int, int]]:
    """Enumerate all 5-tuples and compute all variants and sanitization simulation."""
    indices = [-2, -1, 0, 1, 2]
    weights = compute_weights(indices, OFFSET_O)
    rows: List[Dict[str, object]] = []
    for combo in itertools.product(DIGITS, repeat=5):
        action_interior, post_interior = interior_rewrite(combo)
        action_b0, post_b0 = boundary_rule_i0(combo)
        action_b1, post_b1 = boundary_rule_i1(combo)

        w_before = weighted_sum(combo, weights)
        w_after_interior = weighted_sum(post_interior, weights)
        w_after_b0 = weighted_sum(post_b0, weights)
        w_after_b1 = weighted_sum(post_b1, weights)

        delta_interior = w_after_interior - w_before
        delta_b0 = w_after_b0 - w_before
        delta_b1 = w_after_b1 - w_before

        # sanitization-phase simulation based on interior post
        mapping = deterministic_reconstructor(post_interior)
        post_sanitized, trace = protocol_c_arbitrate(mapping, post_interior, weights)
        w_after_sanitized = weighted_sum(post_sanitized, weights)
        delta_sanitized = w_after_sanitized - w_before

        row = {
            "in_d-2": combo[0], "in_d-1": combo[1], "in_d0": combo[2], "in_d1": combo[3], "in_d2": combo[4],
            "action_interior": action_interior,
            "post_interior_d-2": post_interior[0], "post_interior_d-1": post_interior[1],
            "post_interior_d0": post_interior[2], "post_interior_d1": post_interior[3], "post_interior_d2": post_interior[4],
            "delta_interior": delta_interior,
            "action_boundary_i0": action_b0,
            "post_b0_d-2": post_b0[0], "post_b0_d-1": post_b0[1], "post_b0_d0": post_b0[2], "post_b0_d1": post_b0[3], "post_b0_d2": post_b0[4],
            "delta_b0": delta_b0,
            "action_boundary_i1": action_b1,
            "post_b1_d-2": post_b1[0], "post_b1_d-1": post_b1[1], "post_b1_d0": post_b1[2], "post_b1_d1": post_b1[3], "post_b1_d2": post_b1[4],
            "delta_b1": delta_b1,
            "post_sanitized_d-2": post_sanitized[0], "post_sanitized_d-1": post_sanitized[1],
            "post_sanitized_d0": post_sanitized[2], "post_sanitized_d1": post_sanitized[3], "post_sanitized_d2": post_sanitized[4],
            "delta_sanitized": delta_sanitized,
            "sanitization_trace": " | ".join(trace[:6])
        }
        rows.append(row)
    return rows, weights

def write_csv(rows: List[Dict[str, object]], filename: str):
    header = [
        "in_d-2","in_d-1","in_d0","in_d1","in_d2",
        "action_interior",
        "post_interior_d-2","post_interior_d-1","post_interior_d0","post_interior_d1","post_interior_d2","delta_interior",
        "action_boundary_i0",
        "post_b0_d-2","post_b0_d-1","post_b0_d0","post_b0_d1","post_b0_d2","delta_b0",
        "action_boundary_i1",
        "post_b1_d-2","post_b1_d-1","post_b1_d0","post_b1_d1","post_b1_d2","delta_b1",
        "post_sanitized_d-2","post_sanitized_d-1","post_sanitized_d0","post_sanitized_d1","post_sanitized_d2","delta_sanitized",
        "sanitization_trace"
    ]
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=header)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)

def write_latex_parts(rows: List[Dict[str, object]], prefix: str, rows_per_part: int = ROWS_PER_PART):
    total = len(rows)
    parts = math.ceil(total / rows_per_part)
    for p in range(parts):
        start = p * rows_per_part
        end = min((p + 1) * rows_per_part, total)
        filename = f"{prefix}{p+1}.tex"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(f"% Appendix B: width-5 transition table rows {start+1}--{end}\n")
            f.write("\\begin{table*}[!ht]\n\\centering\n\\footnotesize\n")
            f.write("\\begin{tabular}{rrrrr l rrrrr r}\n")
            f.write("\\toprule\n")
            f.write("in\\_d-2 & in\\_d-1 & in\\_d0 & in\\_d1 & in\\_d2 & action\\_interior & post\\_int\\_d-2 & post\\_int\\_d-1 & post\\_int\\_d0 & post\\_int\\_d1 & post\\_int\\_d2 & d\\_int \\\\\n")
            f.write("\\midrule\n")
            for r in rows[start:end]:
                action = latex_escape(str(r["action_interior"]))
                line = (f"{r['in_d-2']:>2} & {r['in_d-1']:>2} & {r['in_d0']:>2} & {r['in_d1']:>2} & {r['in_d2']:>2} & "
                        f"{action:<16} & {r['post_interior_d-2']:>2} & {r['post_interior_d-1']:>2} & {r['post_interior_d0']:>2} & {r['post_interior_d1']:>2} & {r['post_interior_d2']:>2} & {r['delta_interior']:>2} \\\\\n")
                f.write(line)
            f.write("\\bottomrule\n\\end{tabular}\n\\end{table*}\n")
        # no print to avoid clutter in some environments
    # end parts

def symbolic_proof_identity(offset: int = 0) -> str:
    """
    Short symbolic proof of 2W_i = W_{i+1} + W_{i-2} for W_k = F_{k+offset}.
    """
    lines = []
    lines.append("Symbolic proof of identity 2W_i = W_{i+1} + W_{i-2} with W_k = F_{k+o}:")
    lines.append("Let W_i = F_{i+o}. Then:")
    lines.append("W_{i+1} + W_{i-2} = F_{i+1+o} + F_{i-2+o}.")
    lines.append("Using Fibonacci recurrence F_{n+1} = F_n + F_{n-1}, write F_{i+1+o} = F_{i+o} + F_{i-1+o}.")
    lines.append("Hence W_{i+1} + W_{i-2} = (F_{i+o} + F_{i-1+o}) + F_{i-2+o} = F_{i+o} + (F_{i-1+o} + F_{i-2+o}).")
    lines.append("But F_{i-1+o} + F_{i-2+o} = F_{i+o} by the recurrence shifted by one index.")
    lines.append("Therefore W_{i+1} + W_{i-2} = F_{i+o} + F_{i+o} = 2 F_{i+o} = 2 W_i.")
    lines.append("QED.")
    return "\n".join(lines)

def write_verification_report(rows: List[Dict[str, object]], weights: Dict[int, int], filename: str):
    total = len(rows)
    failures_interior = [r for r in rows if r["delta_interior"] != 0]
    failures_b0 = [r for r in rows if r["delta_b0"] != 0]
    failures_b1 = [r for r in rows if r["delta_b1"] != 0]
    failures_sanit = [r for r in rows if r["delta_sanitized"] != 0]
    with open(filename, "w", encoding="utf-8") as f:
        f.write("Width-5 Transition Table Verification Report\n")
        f.write("===========================================\n\n")
        f.write(f"Total enumerated rows: {total}\n")
        f.write(f"Fibonacci offset (o): {OFFSET_O}\n")
        f.write("Weights used (index -> W_index):\n")
        for k in sorted(weights.keys()):
            f.write(f"  {k:>3} -> {weights[k]}\n")
        f.write("\n")
        f.write(f"Interior rule failures (non-zero delta): {len(failures_interior)}\n")
        f.write(f"Boundary i=0 failures: {len(failures_b0)}\n")
        f.write(f"Boundary i=1 failures: {len(failures_b1)}\n")
        f.write(f"Sanitization-phase failures: {len(failures_sanit)}\n\n")
        if failures_interior:
            f.write("Sample interior failures (up to 20):\n")
            for r in failures_interior[:20]:
                f.write(str({k: r[k] for k in ['in_d-2','in_d-1','in_d0','in_d1','in_d2','delta_interior']}) + "\n")
            f.write("\n")
        if failures_b0:
            f.write("Sample boundary i0 failures (up to 20):\n")
            for r in failures_b0[:20]:
                f.write(str({k: r[k] for k in ['in_d-2','in_d-1','in_d0','in_d1','in_d2','delta_b0']}) + "\n")
            f.write("\n")
        if failures_b1:
            f.write("Sample boundary i1 failures (up to 20):\n")
            for r in failures_b1[:20]:
                f.write(str({k: r[k] for k in ['in_d-2','in_d-1','in_d0','in_d1','in_d2','delta_b1']}) + "\n")
            f.write("\n")
        if failures_sanit:
            f.write("Sample sanitization failures (up to 20):\n")
            for r in failures_sanit[:20]:
                f.write(str({k: r[k] for k in ['in_d-2','in_d-1','in_d0','in_d1','in_d2','delta_sanitized','sanitization_trace']}) + "\n")
            f.write("\n")
        f.write("Symbolic proof of the Fibonacci identity used for interior rewrite:\n\n")
        f.write(symbolic_proof_identity(OFFSET_O))
        f.write("\n\nEnd of report.\n")

def write_sanitization_examples(rows: List[Dict[str, object]], filename: str, limit: int = 200):
    with open(filename, "w", encoding="utf-8") as f:
        f.write("Representative sanitization-phase examples (first {} rows)\n".format(limit))
        f.write("--------------------------------------------------------\n")
        for r in rows[:limit]:
            inp = (r["in_d-2"], r["in_d-1"], r["in_d0"], r["in_d1"], r["in_d2"])
            f.write(f"{inp} -> sanitized post: ({r['post_sanitized_d-2']},{r['post_sanitized_d-1']},{r['post_sanitized_d0']},{r['post_sanitized_d1']},{r['post_sanitized_d2']}) | trace: {r['sanitization_trace']}\n")

def write_readme(filename: str):
    text = (
        "Generation README\n"
        "=================\n\n"
        "This directory contains artifacts produced by scripts/generate_width5_transitions.py.\n\n"
        "To reproduce:\n"
        "  1. Ensure Python 3.8+ is available.\n"
        "  2. Run: python3 scripts/generate_width5_transitions.py\n"
        "  3. Outputs are written to the 'outputs' directory:\n"
        "     - width5_transitions_full.csv\n"
        "     - appendixB_part1.tex ... appendixB_part5.tex\n"
        "     - verification_report.txt\n"
        "     - sanitization_examples.txt\n\n"
        "Notes:\n"
        " - The script uses Fibonacci positional weights W_k = F_{k+o} with offset o configurable in the script.\n"
        " - The verification report contains a symbolic proof of the identity 2W_i = W_{i+1} + W_{i-2}.\n"
    )
    with open(filename, "w", encoding="utf-8") as f:
        f.write(text)

# ---------------------------
# Main execution
# ---------------------------

def main():
    ensure_output_dir()
    print("Generating rows...")
    rows, weights = generate_rows()
    print(f"Total rows generated: {len(rows)}")
    print("Writing CSV...")
    write_csv(rows, CSV_FILENAME)
    print(f"Wrote CSV to {CSV_FILENAME}")
    print("Writing LaTeX fragments...")
    write_latex_parts(rows, TEX_PART_PREFIX, ROWS_PER_PART)
    print("LaTeX fragments written to outputs/")
    print("Writing verification report...")
    write_verification_report(rows, weights, VERIFICATION_FILENAME)
    print(f"Wrote verification report to {VERIFICATION_FILENAME}")
    print("Writing sanitization examples...")
    write_sanitization_examples(rows, SANITIZATION_EXAMPLES)
    print(f"Wrote sanitization examples to {SANITIZATION_EXAMPLES}")
    write_readme(README_FILE)
    print(f"Wrote README to {README_FILE}")
    print("Done. Inspect outputs/ for generated artifacts.")

if __name__ == "__main__":
    main()
