#!/usr/bin/env python3
"""Compatibility entrypoint for the SBA proofbench script."""

from scripts.sba_theory_proofbench import *  # noqa: F401,F403
from scripts.sba_theory_proofbench import main

if __name__ == "__main__":
    main()