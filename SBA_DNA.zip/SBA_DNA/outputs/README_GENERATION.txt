Generation README
=================

This directory contains artifacts produced by scripts/sba_theory_proofbench.py for the IEEE supplementary material repository.

To reproduce:
  1. Ensure Python 3.8+ is available.
  2. Run: python3 scripts/sba_theory_proofbench.py
  3. Outputs are written to the 'outputs' directory for archival in the IEEE supplementary material repository:
     - width5_transitions_full.csv
     - appendixB_part1.tex ... appendixB_part5.tex
     - verification_report.txt
     - sanitization_examples.txt

Notes:
 - The script uses Fibonacci positional weights W_k = F_{k+o} with offset o configurable in the script.
 - The verification report contains a symbolic proof of the identity 2W_i = W_{i+1} + W_{i-2}.