Generation README
=================

This directory contains artifacts produced by scripts/sba_theory_proofbench.py for the IEEE supplementary material repository.

To reproduce:
  1. Ensure Python 3.8+ is available.
  2. Run: python3 scripts/sba_theory_proofbench.py
  3. Outputs are written to the 'outputs' directory for archival in the IEEE supplementary material repository:
     - width5_transitions_full.csv
     - appendixB_part1.tex ... appendixB_part5.tex
     - verification_report.txt
     - sanitization_examples.txt

Notes:
 - The script uses Fibonacci positional weights W_k = F_{k+o} with offset o configurable in the script.
 - The verification report contains a symbolic proof of the identity 2W_i = W_{i+1} + W_{i-2}.

Prime-number analysis options (unified in proofbench)
-----------------------------------------------------
The script `scripts/sba_theory_proofbench.py` now includes two prime-analysis
modules in addition to the original SBA verification pipeline:

- `--prime`
  Runs the matched odd-only prime-vs-composite SBA feature experiment
  (cross-validated linear score + permutation null).

  Generated artifacts in `outputs/`:
  - `prime_composite_sba_features.csv`
  - `prime_composite_sba_univariate.csv`
  - `prime_composite_sba_results.json`
  - `prime_composite_sba_summary.txt`

- `--phase`
  Runs the SBA phase-map concentration test with stratified null models
  (label-permutation and phase-randomized nulls).

  Generated artifacts in `outputs/`:
  - `prime_phase_map_dataset.csv`
  - `prime_phase_map_perL_center_all.csv`
  - `prime_phase_map_results.json`
  - `prime_phase_map_summary.txt`

Usage examples:
- `python3 scripts/sba_theory_proofbench.py --prime --outdir outputs`
- `python3 scripts/sba_theory_proofbench.py --phase --outdir outputs`
- `python3 scripts/sba_theory_proofbench.py --all --outdir outputs`

Note: `--all` runs both modules plus the original proofbench tasks
(width-5 enumeration/verification, symbolic check, energy examples, toy
simulation, and unit tests).
